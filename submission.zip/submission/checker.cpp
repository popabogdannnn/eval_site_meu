#include <bits/stdc++.h>

using namespace std;

int main() {
    cout << "50\n";
    cout << "Raspuns partial corect.";
    return 0;
}